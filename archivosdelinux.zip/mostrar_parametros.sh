#!/bin/bash

# Script que muestra los parámetros pasados como argumentos
if [ $# -eq 0 ]; then
    echo "No se pasaron parámetros."
    echo "Uso: $0 parametro1 [parametro2 ...]"
    exit 1
fi

echo "Parámetros recibidos:"
for param in "$@"; do
    echo "- $param"
done

echo
echo "Comprobando si los usuarios están conectados:"
for usuario in "$@"; do
  estado=$(./usuarioconectado "$usuario")
  echo "$usuario → $estado"
done

echo
echo "Comprobando si los usuarios están conectados:"
for usuario in "$@"; do
  estado=$(./usuarioconectado "$usuario")
  echo "$usuario → $estado"
done

echo
echo "Comprobando si los usuarios están conectados:"
for usuario in "$@"; do
  estado=$(./usuarioconectado "$usuario")
  echo "$usuario → $estado"
done

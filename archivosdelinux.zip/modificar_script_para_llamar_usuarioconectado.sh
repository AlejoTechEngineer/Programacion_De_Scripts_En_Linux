#!/bin/bash

# Nombre del script a modificar
SCRIPT_OBJETIVO="mostrar_parametros.sh"

# Verificamos que exista el archivo
if [ ! -f "$SCRIPT_OBJETIVO" ]; then
  echo "Error: El archivo $SCRIPT_OBJETIVO no existe."
  exit 1
fi

# Hacemos copia de seguridad antes de modificar
cp "$SCRIPT_OBJETIVO" "${SCRIPT_OBJETIVO}.bak"

# Añadimos llamada al script usuarioconectado al final
cat << 'EOF' >> "$SCRIPT_OBJETIVO"

echo
echo "Comprobando si los usuarios están conectados:"
for usuario in "$@"; do
  estado=$(./usuarioconectado "$usuario")
  echo "$usuario → $estado"
done
EOF

echo "Script '$SCRIPT_OBJETIVO' modificado exitosamente."
echo "Se añadió una llamada a 'usuarioconectado' por cada argumento recibido."

#!/bin/bash

# Script que verifica que se haya pasado al menos un parámetro, los muestra separados por comas
# y muestra una ayuda en caso de error

# Función para mostrar la ayuda
mostrar_ayuda() {
    echo "Uso: $0 parametro1 [parametro2 ...]"
    echo ""
    echo "Descripción:"
    echo "  Este script toma uno o más parámetros y los imprime en una sola línea, separados por comas."
    echo ""
    echo "Ejemplos:"
    echo "  $0 hola mundo         # Imprime: hola,mundo"
    echo "  $0 uno dos tres       # Imprime: uno,dos,tres"
    echo ""
    echo "Notas:"
    echo "  - Debes proporcionar al menos un parámetro."
    echo "  - Los parámetros pueden ser palabras o números."
    exit 1
}

# Verifica si se pasó al menos un parámetro
if [ $# -lt 1 ]; then
    echo "Error: Debes introducir al menos un parámetro."
    mostrar_ayuda
fi

# Construye la cadena de parámetros separados por comas
PARAMS=""
for param in "$@"; do
    if [ -z "$PARAMS" ]; then
        PARAMS="$param"
    else
        PARAMS="$PARAMS,$param"
    fi
done

echo "Parámetros recibidos: $PARAMS"

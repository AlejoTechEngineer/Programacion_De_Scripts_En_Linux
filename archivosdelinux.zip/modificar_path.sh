#!/bin/bash

# Ruta de la carpeta de ejercicios (modifica esta ruta según tu caso)
CARPETA_EJERCICIOS="/ruta_carpeta_ejercicios"

# Archivo .bashrc
BASHRC="$HOME/.bashrc"

# Verifica si la carpeta existe
if [ ! -d "$CARPETA_EJERCICIOS" ]; then
    echo "Error: La carpeta $CARPETA_EJERCICIOS no existe"
    exit 1
fi

# Verifica si la línea ya está en .bashrc para evitar duplicados
if grep -Fx "export PATH=\$PATH:$CARPETA_EJERCICIOS" "$BASHRC" > /dev/null; then
    echo "La ruta ya está en $BASHRC"
    exit 0
fi

# Añade la línea al final de .bashrc
echo "export PATH=\$PATH:$CARPETA_EJERCICIOS" >> "$BASHRC"

echo "Ruta $CARPETA_EJERCICIOS añadida al PATH en $BASHRC"
echo "Ejecuta 'source ~/.bashrc' para aplicar los cambios en la sesión actual"

#!/bin/bash

# Script que verifica que se haya pasado al menos un parámetro y los muestra
if [ $# -lt 1 ]; then
    echo "Error: Debes introducir al menos un parámetro."
    echo "Uso: $0 parametro1 [parametro2 ...]"
    exit 1
fi

echo "Parámetros recibidos:"
for param in "$@"; do
    echo "- $param"
done

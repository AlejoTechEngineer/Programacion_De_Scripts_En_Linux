#!/bin/bash

# Script que verifica que se haya pasado al menos un parámetro, comprueba si son usuarios conectados
# y los muestra separados por comas, con una ayuda en caso de error

# Función para mostrar la ayuda
mostrar_ayuda() {
    echo "Uso: $0 usuario1 [usuario2 ...]"
    echo ""
    echo "Descripción:"
    echo "  Este script toma uno o más nombres de usuarios y verifica si están conectados al sistema."
    echo "  Los usuarios conectados se imprimen en una sola línea, separados por comas."
    echo ""
    echo "Ejemplos:"
    echo "  $0 user1 user2       # Imprime: user1,user2 (si ambos están conectados)"
    echo "  $0 root              # Imprime: root (si root está conectado)"
    echo ""
    echo "Notas:"
    echo "  - Debes proporcionar al menos un nombre de usuario."
    echo "  - Solo se mostrarán los usuarios que estén actualmente conectados."
    exit 1
}

# Verifica si se pasó al menos un parámetro
if [ $# -lt 1 ]; then
    echo "Error: Debes introducir al menos un parámetro."
    mostrar_ayuda
fi

# Construye la cadena de usuarios conectados
PARAMS=""
for param in "$@"; do
    # Verifica si el usuario está conectado usando 'who'
    if who | grep -w "$param" > /dev/null; then
        if [ -z "$PARAMS" ]; then
            PARAMS="$param"
        else
            PARAMS="$PARAMS,$param"
        fi
    fi
done

# Verifica si se encontraron usuarios conectados
if [ -z "$PARAMS" ]; then
    echo "Error: Ninguno de los usuarios proporcionados está conectado."
    mostrar_ayuda
else
    echo "Usuarios conectados: $PARAMS"
fi

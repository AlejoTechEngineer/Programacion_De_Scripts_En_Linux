#!/bin/bash

# Script que verifica que se haya pasado al menos un parámetro y los muestra separados por comas
if [ $# -lt 1 ]; then
    echo "Error: Debes introducir al menos un parámetro."
    echo "Uso: $0 parametro1 [parametro2 ...]"
    exit 1
fi

# Construye la cadena de parámetros separados por comas
PARAMS=""
for param in "$@"; do
    if [ -z "$PARAMS" ]; then
        PARAMS="$param"
    else
        PARAMS="$PARAMS,$param"
    fi
done

echo "Parámetros recibidos: $PARAMS"
